<style>
    h1 {
        color: #1db954;
        margin-bottom: 0;
    }
    h4 {
        color: #535353;
        margin: 0;
    }
</style>

<h1>Album tracker</h1>
<h4>Hoeveel nummers staan er nou eigenlijk op een album en hoeveel albums heeft een artiest dan?</h4>