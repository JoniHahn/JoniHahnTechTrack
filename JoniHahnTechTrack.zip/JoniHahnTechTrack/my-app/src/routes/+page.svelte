<script>
    import Header from "../components/Header.svelte";
    import BarChart from "../components/BarChart.svelte";
    import Footer from "../components/Footer.svelte";
    

</script>

    <Header/>
    <BarChart />
    <Footer />
 
    

<style>

</style>