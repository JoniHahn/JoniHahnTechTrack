<style>
    p {
        display: flex;
        justify-content: center;
        color: #b3b3b3;
    }

    p:last-of-type {
        padding-bottom: 1em;
    }
</style>

<p>&copy; 2024 multipule artist albums. All rights reserved.</p>
  <p>Data sourced from <a href="https://developer.spotify.com/documentation/web-api" target="_blank" style="color: #1e90ff;">Spotify API</a></p>
  <p>Created by [Joni Sara Hahn].</p>