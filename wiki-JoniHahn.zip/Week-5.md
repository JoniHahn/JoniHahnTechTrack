Deze week zijn we gaan testen altijd fijn want dan weet je wat je nog verbeteren voor een beter cijfer.
<br> Op maandag zijn we een testplan gaan schrijven die we de volgende dag gingen uitvoeren. Ik was van plan om een thinking outloud te doen omdat mijn visualisatie toch op een pagina blijft en de titel voor voor zich lijkt en ook denk dat op deze manier je de meeste informatie terug krijg van de tester.
<p>We hebben twee keer getest met iemand en dit is de feedback dat vanuit mij kwam.
<br><strong>UxUi</strong>
<ul>
<li>leuk idee</li>
<li>Denken dat de albums boven in nummers zijn.</li>
<li>Meer info voor de duidelijkheid</li>
<li>Laat het op een scherm passen</li>
<li>Hover over een bolletje en bekijk het nummer</li>
</ul>
<br><strong>Code review</strong>
<ul>
<li>; weghalen want dat zou niet te hoeven in svelte</li>
<li>Er zijn wel comments maar kan beter ook voor duidelijk voor jezelf</li>
<li>de client id en secret in een .env bestand zetten</li>
<li>Kijken naar een andere d3 chart</li>
<li>Benaming van libraries kan anders</li>
<li>Commments makkelijker maken</li>
</ul>

<p> uiteindelijk heb ik dat probleem van vorige week opgelost en ben ik een beetje aan de styling gaan werken.