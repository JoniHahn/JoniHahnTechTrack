<h1>Design Rationale: Een drastische wending in mijn project

<p>Tijdens mijn project heb ik mijn oorspronkelijke plan volledig moeten omgooien door onverwachte technische beperkingen. In deze design rationale wil ik uitleggen wat er precies is gebeurd, waarom ik bepaalde keuzes heb gemaakt, en hoe ik mijn focus heb verlegd om toch een werkend eindresultaat te kunnen presenteren.

<p><strong>Het oorspronkelijke idee</strong>
<br>Mijn hoofdvraag was: “Op welke nummers van Taylor Swift kun je het beste dansen?” Hiervoor wilde ik een scatterplot maken. Het idee was dat je met je muis over de bolletjes kon gaan om extra informatie te zien, zoals de titel van het nummer en het album waar het bij hoorde. Dit sloot goed aan bij mijn leerdoelen, omdat ik daarmee niet alleen data moest visualiseren, maar ook interactie kon toevoegen met D3.js.

<p><strong>De wending: Technische beperkingen</strong>
<br>We hadden zes weken om dit project te voltooien. Echter, precies één dag voor de inleverdatum besloot Spotify bepaalde API-endpoints te blokkeren die essentieel waren voor mijn visualisatie. Dit betekende dat alle code die ik had geschreven plotseling nutteloos werd. De aankondiging hierover werd gedaan in de officiële blogpost van Spotify:
https://developer.spotify.com/blog/2024-11-27-changes-to-the-web-api

<p>Omdat deze endpoints niet meer beschikbaar waren, kon ik mijn visualisatie niet langer ondersteunen met de benodigde gegevens. Hierdoor moest ik last-minute mijn plan aanpassen.

<strong>De nieuwe aanpak</strong>
Mijn doel werd om ondanks de beperkingen toch aan te tonen dat ik de stof beheers, zoals het fetchen van data en het gebruik van D3.js. Ik besloot een nieuwe visualisatie te maken, gebaseerd op de gegevens die nog wel beschikbaar waren. Dit betekende dat ik mijn focus verlegde naar het visualiseren van de release-dates en het aantal nummers per album.

<p>De keuze om geen persoonlijke data van gebruikers te fetchen (zoals andere projecten wel deden), kwam voort uit twee overwegingen:

<p>Ik wilde voorkomen dat mijn project teveel zou lijken op dat van anderen, zoals het werk van Binc.
De setup voor mijn nieuwe endpoints was snel in gebruik te nemen zonder dat ik opnieuw moest werken met complexe authenticatie of logins.
In een aparte map heb ik mijn oude code en screenshots toegevoegd, zodat duidelijk is wat ik oorspronkelijk van plan was. Deze code heb ik niet meer aangepast, omdat ik de focus volledig op mijn nieuwe oplossing heb gelegd.

Screenshots van het oorspronkelijke design
<img width="772" alt="Schermafbeelding 2024-11-15 om 11 22 54 AM" src="https://github.com/user-attachments/assets/90f5c5b4-1b1b-46fd-8d28-485c39c6215e">
<img width="1440" alt="Schermafbeelding 2024-11-22 om 2 20 03 PM" src="https://github.com/user-attachments/assets/b697ce6b-aea3-4004-ba49-a3aeb5ed2779">

<strong>Reflectie op het eindresultaat</strong>
Mijn uiteindelijke visualisatie is qua inhoud niet zo interessant als ik had gehoopt. Dit komt doordat ik beperkt was tot eenvoudige gegevens zoals releasedata en het aantal nummers per album. Mijn focus lag vooral op het laten zien dat ik technieken zoals fetching en D3.js begrijp en kan toepassen.

<p>Als ik meer tijd had gehad, had ik meer aandacht besteed aan het design en interacties toegevoegd. Door de focus op het herschrijven van de visualisatie bleef hier weinig tijd voor over. Ook had ik niet meer de motivatie om verder te gaan, aangezien ik mijn oorspronkelijke plan niet meer kon realiseren.

<strong>Belangrijke notitie:</strong>
De oude code is niet aangepast of geoptimaliseerd. Het is mogelijk dat deze niet perfect is, omdat ik nog plannen had om verbeteringen door te voeren. Helaas kon ik dit niet meer testen of afronden, aangezien de benodigde data niet meer beschikbaar is.

<strong>Toekomstplannen</strong>
Na de beoordeling zal ik mijn app verwijderen uit de Spotify API om te voorkomen dat anderen mijn codes kunnen gebruiken. In de toekomst overweeg ik om dit project opnieuw op te pakken. Dan zal ik ofwel een nieuwe app aanmaken of een volledig nieuwe insteek kiezen met dezelfde basisideeën.
<hr>
Met deze drastische wending heb ik vooral geleerd hoe belangrijk het is om flexibel te blijven en met beperkte middelen toch iets werkends neer te zetten.











