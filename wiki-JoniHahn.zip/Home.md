<strong>Hoi iedereen!</strong>
<br>In de komende paar pagina’s laat ik je zien hoe mijn 6 weken durende Tech Track-project is geëindigd. Je kunt hier ook lezen welke stappen ik allemaal heb doorlopen om tot het eindresultaat te komen.

Hopelijk vind je het interessant om te zien hoe alles is gegaan!