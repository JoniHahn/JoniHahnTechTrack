<h1>Week 1: De start van de Tech Track

<p>In de eerste week begonnen we met een introductie over wat we precies gingen doen tijdens de Tech Track. We leerden wat we de komende weken zouden oppakken en hoe ons eindproduct eruit zou zien. Het idee is dat we uiteindelijk een grafiek gaan maken met code, gebaseerd op een zelfgekozen onderwerp en dataset.

<p>Voor degenen die het nodig vonden (waar ik er ook een van was), waren er kleine opdrachten beschikbaar om je JavaScript-kennis wat bij te spijkeren. Daarnaast waren er ook oefeningen om nieuwe concepten te leren. Dit ging vooral over dingen als scope, map(), filter(), reduce(), en de verschillen tussen pure en impure functions. Ook kwam het gebruik van return uitgebreid aan bod.

<p>Tot slot hebben we al een eerste blik geworpen op ons eigen project. We moesten nadenken over welk onderwerp we wilden kiezen voor onze visualisatie en welke dataset we daarvoor wilden gebruiken. Het was belangrijk dat de dataset dynamisch zou zijn, zodat we daar later flexibel mee konden werken.
<hr>

Zo voelde de eerste week als een goede opstart, met een combinatie van terugkijken en nieuwe dingen leren! 😊






