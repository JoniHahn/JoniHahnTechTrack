<h1>Week 2: Het kiezen van een onderwerp en kennismaken met nieuwe tools

<p>Aan het einde van vorige week hadden we al nagedacht over wat we wilden visualiseren. Mijn eerste idee was om iets met boeken te doen, maar het gebruik van een API hiervoor bleek betaald te zijn. Dat risico wilde ik liever niet nemen. Daarna kwam ik op het idee om iets met muziek te doen, en vooral met Taylor Swift. Ik vond een interessante dataset op Kaggle:

<strong>De dataset:
<br>https://www.kaggle.com/datasets/jarredpriester/taylor-swift-spotify-dataset/data

Mijn onderzoeksvraag werd uiteindelijk: “Op welke nummers van Taylor Swift kun je het beste dansen?” De dataset bevatte namelijk allerlei cijfers, zoals danceability, energy, en nog veel meer.

<strong>Mijn visualisatie-idee:</strong>
Ik had een visueel concept in mijn hoofd en werkte dit uit. Hier is een link naar mijn eerste schets:
https://xd.adobe.com/view/33229a5e-14c5-44a0-b096-14bddfc4a3ed-6671/

<p>De rest van de week stond in het teken van uitleg over frameworks, D3, en libraries. We hebben deze tools geïnstalleerd en er meteen wat mee geoefend. Niet iedereen had eerder met een framework gewerkt, en dat gold ook voor mij. Vooral Svelte was nieuw terrein. Na wat proberen, oefenen, en vragen stellen, kreeg ik er gelukkig steeds meer grip op. Nu zie ik ook echt het nut in van frameworks, vooral bij het bouwen van dynamische visualisaties.
<hr>
Al met al was dit een week waarin ik mijn project concreter maakte en nieuwe skills leerde die me verder gaan helpen! 😊















