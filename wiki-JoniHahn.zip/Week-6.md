De laatste week begon voor mij erg goed. Ik was al best ver met mijn project en voelde me positief over de voortgang. Maar toen sloeg de situatie om. Zoals ik eerder heb vermeld, kon ik ineens bepaalde endpoints niet meer opvragen. Hierdoor moest ik mijn hele project omgooien. Meer over deze beslissing kun je lezen in mijn design rationale.

<p>Gelukkig is het me, ondanks de tegenslag, wel gelukt om Vercel goed werkend te krijgen. Dit was een opluchting, omdat ik ervan overtuigd ben dat er eerder misschien een stukje code was dat niet helemaal goed functioneerde. Ik heb de nieuwe grafiek ook weer van d3 gehaald en zo geschreven dat het op mijn data paste en hier ook weer de link https://observablehq.com/@d3/horizontal-bar-chart/2.

<p>Daarnaast heb ik geprobeerd mijn secret keys in een .env-bestand te zetten, maar dat ging niet helemaal zoals gepland. Ik heb dit zelf geprobeerd en ook filmpjes opgezocht, zoals deze:
https://www.youtube.com/watch?v=ai8PJgxF9Lw

<p>Dit leidde me uiteindelijk naar de officiële documentatie:
https://svelte.dev/docs/kit/$env-dynamic-private

<p>Toch kreeg ik het niet werkend. Het probleem zat erin dat ik geen geldige API-token meer kon ophalen, waardoor het misging bij het .env-bestand. Ik heb nog samen met Ali gekeken waar het fout ging. Het is uiteindelijk nog gelukt heb de oude api app verwijderd toen even nog even gekeken omdat het ook niet hellemaal ging met vercel. Bleek het dat je nog apart je client secret enzo apart er in moet zetten.

<p>Er is uiteindelijk iets komen te staan wat misschien anders is dan verwacht. 

</hr>
Het was een hectische laatste week, maar een leerzame afsluiting van dit project. 🚀

